# NexusRetail – Intelligent Customer Lifecycle Optimization

**Business Analyst portfolio project** · Omni-channel retail / e-commerce
NexusRetail is a fictional company and all data is synthetic. The dataset covers **42,000 cart sessions (Jan–Dec 2025)** and **8,500 customers** in six European markets (GR, CY, DE, IT, FR, ES).

**Business question:** where does NexusRetail lose revenue and customer trust across the lifecycle (cart → checkout → post-purchase → retention), and what should it fix first?

**Start here (3 minutes):** read the Executive Insight below, then open `NexusRetail_Analysis.xlsx` (sheet *Summary*). Every number in the workbook is a live formula on the data sheets.

---

## Executive Insight

### 1. What (what happened)

* **40.3%** of cart sessions (16,908 of 42,000) ended in abandonment; conversion is 59.7%.
* The abandoned carts were worth **€1.19M** in 2025, against €1.76M of completed revenue.
* Abandonment is **45.0% on Mobile**, 34.2% on Desktop and 40.1% on Tablet.
* When a **payment fails**, abandonment reaches **75.0%** (38.0% when it does not).
* Average refund processing time is **15.1 days** (median 15, P90 25). Only 19.7% of refunds complete within 7 days. Returns are 5.1% of completed orders (1,276).
* Of 8,500 customers, **11.5% (978) are At-Risk** and **6.1% (515) have Churned**; 21.6% are Loyal.

### 2. Why (why it happened)

Metric tree:

```
Revenue leakage (€1.19M) = Abandoned carts (16,908) × Average cart value (€70.12)
Abandoned carts          = Sessions (42,000) × Abandonment rate (40.3%)
Abandonment rate         ← Device (Mobile vs Desktop)  +  Payment failure
```

* **Device:** Mobile is 52.2% of sessions and abandons **10.9 pp more** than Desktop. That is about 2,385 extra abandoned carts (≈ €167k), and Mobile holds 58% of the abandoned value. The difference is statistically significant (chi-square, Mobile vs rest: χ² = 435.2, p ≈ 1e-96; Mobile vs Desktop: χ² = 472.2, p ≈ 1e-104).
* **Payment:** only 6.1% of sessions have a payment failure, but they abandon at 75%. They account for 11.3% of all abandonments (€135k).
* **What does not explain it:** sales channel (40.1–41.1%), customer segment (39.6–40.6%) and quarter (39.8–41.1%) barely differ. The problem is systemic and concentrated in device and payment.
* **Root causes are hypotheses.** The dataset measures outcomes, not stages. Why Mobile checkout loses more carts (steps, form fields) and why refunds are slow (hand-offs, quality check, finance batch) come from the process review and must be measured (see recommendation 8).

### 3. So What (what it means in practice)

* Each **1 pp** reduction in abandonment is worth ≈ **€29k** of revenue per year. The target of −4 to −7 pp equals **€118k–€206k**. Recovering 18% of abandoned value (€213k, ≈ 7.2 pp) is a theoretical ceiling, not the base case.
* **Mobile is the biggest opportunity** (largest volume and largest gap). Payment failure is small in volume but severe per session, so a cheap fix has a high impact per incident.
* Refunds are far from a 5-day standard: only 12.5% of refunds finish within 5 days. The cost is mostly trust and experience rather than visible revenue. The data shows **no ticket uplift on returns** (4.3% of returned orders have a support ticket vs 12.2% of other completed orders), so no support saving is assumed.
* The **978 At-Risk customers** (last purchase 45–118 days ago) can still be won back; Churned customers start at 120 days.
* **Business case (revenue basis):** Base Year-1 net ≈ **+€52k**, payback ≈ 8 months. The Conservative case is slightly negative in Year 1 (−€12k, payback ≈ 13 months) and positive after 24 months (+€106k). Recovered revenue is not profit: at a 35% placeholder gross margin the Base payback becomes ≈ 23 months. Margin and cost must be confirmed by Finance before approval.

### 4. Now What (what we recommend doing now)

**0–30 days**
1. Real-time cart recovery within 15–30 minutes of abandonment, with an A/B test and a control group.
2. Clear message and alternative payment methods when a payment fails.
3. Reduce Mobile checkout friction (guest checkout, digital wallets).

**30–90 days**
4. Self-service returns portal with status tracking, targeting refunds within 5 days.
5. One lifecycle dashboard (funnel, refund SLA, segment health).
8. Capture checkout-step events and refund-stage timestamps, so root causes are measured instead of assumed (runs alongside 1–5).

**90–180 days**
6. Predictive At-Risk scoring that feeds the CRM, prioritising customers 45–118 days since last purchase.
7. Dynamic loyalty tiers based on RFM and engagement.

**Before approval:** Finance confirms gross margin and implementation cost (yellow cells in the `Business_Case` sheet). Ask of leadership: approve Phase 1 and name an executive sponsor.

---

## Key figures

| Metric | Value |
|---|---|
| Cart sessions | 42,000 |
| Cart abandonment | 40.3% |
| Abandonment: Mobile / Desktop / Tablet | 45.0% / 34.2% / 40.1% |
| Abandonment when payment fails | 75.0% |
| Completed revenue | €1.76M |
| Abandoned cart value | €1.19M |
| Value of a 1 pp reduction in abandonment | ≈ €29k |
| Return rate (completed orders) | 5.1% (1,276 returns) |
| Refund processing time: average / median / P90 | 15.1 / 15 / 25 days |
| Loyal / At-Risk / Churned customers | 21.6% / 11.5% / 6.1% |

## Process diagrams

AS-IS vs TO-BE swimlanes (PNG and SVG in `diagrams/`):

![Checkout and cart recovery](diagrams/01_checkout_cart_recovery_AS-IS_TO-BE.png)

![Returns and refunds](diagrams/02_returns_refund_AS-IS_TO-BE.png)

## Project structure

```
README.md
NexusRetail_Analysis.xlsx        Excel model: Summary, KPIs, Business_Case, Data_Quality, Data_Sessions, Data_Customers
analysis/
  validate_data.py               15 integrity checks on the data
  statistical_analysis.py        computes all statistics -> outputs/key_statistics.json
data/
  full_dataset.csv               sessions joined with customer attributes (42,000 rows)
  orders.csv                     order-level columns of full_dataset.csv
  customers.csv                  customer table (8,500 rows)
  data_quality_log.csv           data preparation notes and known limitations
  DATA_DICTIONARY.md             column definitions
documents/
  01_Business_Requirements_Summary.md
  02_Process_AS-IS_TO-BE.md
  03_Stakeholder_Analysis_and_RACI.md
  04_Prioritised_Recommendations_and_Business_Case.md
  05_User_Stories_and_Acceptance_Criteria.md
diagrams/                        two AS-IS / TO-BE swimlane diagrams (PNG + SVG) and a short index
outputs/key_statistics.json
requirements.txt
```

## How to reproduce

```bash
pip install -r requirements.txt
python analysis/validate_data.py          # 15/15 checks should pass
python analysis/statistical_analysis.py   # rewrites outputs/key_statistics.json
```

## Method, assumptions and limits

* **Statistics:** funnel and segment rates, chi-square tests (Mobile vs rest and Mobile vs Desktop; payment failure vs no failure), refund-time percentiles, and a three-scenario business case.
* **Valid returns:** a return counts only for a completed order with refund days recorded (1,276). Details are in `data/data_quality_log.csv` and the `Data_Quality` sheet.
* **Assumptions that are not outputs of the data:** abandonment-reduction targets (−4 / −5.5 / −7 pp), implementation costs (€130k / €110k / €90k), gross margin (35% placeholder) and the 18% reference recovery rate. They are blue or yellow input cells in `Business_Case`.
* **Segments:** only At-Risk (45–118 days since last purchase) and Churned (120+ days) are separated by recency. New, Occasional and Loyal customers all bought within 43 days, and their definitions are not documented in the dataset.
* **Dataset quirks:** `sales_channel` does not always agree with `device` (so the Mobile/Desktop analysis uses `device`); refund days are calendar days with an undocumented start point; 58 customers have no session.
* **Synthetic data:** findings describe this dataset, not a real company.

## Skills demonstrated

Problem framing and opportunity sizing · funnel and segment analysis with statistical testing · metric trees · AS-IS / TO-BE process mapping · stakeholder analysis and RACI · requirements and user stories with acceptance criteria · business case with scenarios and a margin sensitivity · data validation · executive storytelling (What → Why → So What → Now What).
