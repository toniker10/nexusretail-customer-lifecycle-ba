# Prioritised Recommendations & Business Case

## Executive Summary of Opportunity

From the statistical analysis of 42,000 sessions:
- Abandoned cart value = **€1.19M** (12 months, Jan–Dec 2025)
- Each 1 pp reduction in abandonment ≈ **€29k** of revenue per year
- Target of −4 to −7 pp ≈ **€118k–€206k** recovered revenue; an 18% recovery of abandoned value (**€213k**, ≈ 7.2 pp) is treated as a theoretical ceiling
- Additional soft benefits (not quantified): higher NPS, improved loyalty programme economics

## Prioritised Interventions

### Tier 1 – Quick Wins (0–30 days) | High Impact / Low Effort
1. **Real-time cart recovery messaging**  
   Trigger within 15–30 min of abandonment. Personalise by cart value and segment.  
   Expected lift: 3–5 pp recovery rate on targeted carts (assumption, to be validated by A/B test).

2. **Payment failure recovery UX**  
   Replace generic errors with clear next steps + alternative payment options.  
   Addresses the 75% abandonment on payment fail (6.1% of sessions, 11.3% of all abandonments, €135k of abandoned value).

3. **Mobile checkout friction reduction**  
   Guest checkout + digital wallet priority.  
   Targets the 45% mobile abandonment rate (+10.9 pp vs Desktop ≈ 2,385 extra abandoned carts ≈ €167k).

### Tier 2 – Process Redesign (30–90 days)
4. **Returns self-service portal + SLA**  
   Target: refund cycle ≤ 5 business days (today 12.5% of refunds complete within 5 calendar days). Status tracking for customer.  
   Improves post-purchase NPS; ticket savings are not quantified because the data shows no ticket uplift on returns.

5. **Unified Customer Lifecycle dashboard**  
   Single view of funnel, refund SLA, segment health for weekly commercial review.

### Tier 3 – Strategic Capability (90–180 days)
6. **Predictive At-Risk scoring + automated journeys**  
   Daily scoring feeding CRM. Focus on the 11.5% At-Risk population (978 customers, last purchase 45–118 days ago).

7. **Dynamic loyalty tier engine**  
   Move beyond simple points to RFM + engagement based tiers.

### Enabler – Measurement (runs alongside Tier 1–2)
8. **Measurement foundation**  
   Capture checkout step events and refund stage timestamps so that the root causes of mobile friction and slow refunds are measured rather than assumed.

## High-Level Financial Assumptions (illustrative)

| Item | Conservative | Base | Optimistic |
|------|--------------|------|------------|
| Abandonment reduction (assumption) | −4.0 pp | −5.5 pp | −7.0 pp |
| Recovered revenue | €118k | €162k | €206k |
| Equivalent recovery of abandoned value | 9.9% | 13.7% | 17.4% |
| Support cost reduction (returns) | not quantified (€0) | €0 | €0 |
| Implementation cost, Phase 1+2 (assumption) | €130k | €110k | €90k |
| Net Year-1 impact (revenue basis) | −€12k | +€52k | +€116k |
| Simple payback (revenue basis) | ~13 months | ~8 months | ~5 months |
| Cumulative net after 24 months (revenue basis) | +€106k | +€214k | +€322k |

**Margin check:** recovered revenue is not profit. At a placeholder gross margin of 35% (to be confirmed by Finance) Year-1 net is −€89k / −€53k / −€18k and Base payback is ~23 months; Year-1 break-even margins are 110% / 68% / 44%.

*Abandonment-reduction targets, implementation costs and margin are assumptions, not outputs of the data. The live model is in the Excel workbook (sheet Business_Case); all figures recalculate when the yellow cells change.*

## Implementation Roadmap (Phased)

**Phase 0 (Discovery – complete in this project)**  
Problem framing, data analysis, process mapping, requirements, business case.

**Phase 1 (Quick Wins)**  
Recovery messaging + payment UX + mobile guest path. A/B tests. Measure.

**Phase 2 (Process & Visibility)**  
Returns portal MVP + dashboard live. SLA governance.

**Phase 3 (Intelligence)**  
Scoring model + loyalty logic + continuous optimisation.

## Risk Register (selected)

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Over-messaging → unsubscribe / consent issues | Medium | High | Frequency caps + preference centre |
| Technical integration delays | Medium | Medium | API-first, phased events |
| Optimistic recovery assumptions | Medium | Medium | Start with conservative targets + measure |
| Change resistance in Ops / Support | Low-Med | Medium | Early involvement + clear “what’s in it for me” |

## Recommendation to Leadership

Approve Phase 1 funding and designate an executive sponsor, conditional on Finance confirming gross margin and implementation cost. The quantified revenue leakage (€1.19M), clear process gaps and prioritised, testable interventions justify starting with the lowest-cost quick wins and A/B testing before committing to the full programme.
