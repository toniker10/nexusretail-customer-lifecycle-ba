# User Stories & Acceptance Criteria (Selected)

Stories follow the INVEST principles and include Gherkin-style acceptance criteria where useful.

---

### Epic: Cart Recovery & Checkout Optimisation

**US-01**  
As a customer who abandons a cart on mobile,  
I want a simple way to complete my purchase later,  
so that I don’t lose the items I selected.

**Acceptance Criteria:**
- Given a customer abandons a cart with value > €40  
  When 20 minutes have passed without purchase  
  Then a recovery message is sent via the preferred channel (push/email)  
  And the message contains a direct deep-link to the exact cart  
  And the message respects marketing consent and frequency rules.

**US-02**  
As a customer whose payment fails,  
I want clear guidance on what to do next,  
so that I can complete the order without frustration.

**Acceptance Criteria:**
- Given a payment attempt fails  
  When the error is displayed  
  Then the customer sees a plain-language explanation  
  And at least one alternative payment method is offered  
  And the cart is automatically saved for 48 hours.

---

### Epic: Returns Experience

**US-03**  
As a customer initiating a return,  
I want to track the status of my refund,  
so that I know when to expect my money.

**Acceptance Criteria:**
- Given a return has been registered  
  When the customer logs into the returns portal  
  Then they see a timeline with current status (Received / Inspected / Refunded)  
  And an estimated refund date is shown  
  And they receive a notification when status changes.

**US-04**  
As an Operations Manager,  
I want refund cycle time to be visible and under SLA,  
so that we can manage capacity and customer expectations.

**Acceptance Criteria:**
- A dashboard shows P50 and P90 refund cycle time by warehouse and by day  
- Alerts are raised when P90 exceeds 7 business days  
- Root-cause categories (transit delay, quality hold, finance batch) are available for drill-down.

---

### Epic: Customer Lifecycle Management

**US-05**  
As a CRM Manager,  
I want customers automatically classified into lifecycle segments,  
so that we can prioritise retention actions.

**Acceptance Criteria:**
- Segments (New / Occasional / Loyal / At-Risk / Churned) are recalculated daily  
- Rules are documented and version-controlled  
- At-Risk customers appear in a prioritised work queue within 24 hours of status change  
- Segment distribution is visible on the executive dashboard.

**US-06**  
As a Marketing Analyst,  
I want to measure the lift of recovery and retention campaigns,  
so that we can optimise spend and messaging.

**Acceptance Criteria:**
- Every recovery campaign has a defined control group  
- Conversion and revenue lift are calculated with statistical significance indicators  
- Results feed back into the prioritisation of future interventions.

---

These stories are traceable to the functional requirements in the BRD Summary (FR-01 to FR-07) and support the business goals BG-01 to BG-04.
