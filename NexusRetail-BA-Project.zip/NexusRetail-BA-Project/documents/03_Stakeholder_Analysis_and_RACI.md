# Stakeholder Analysis & RACI Matrix

## Key Stakeholders

| Stakeholder | Interest / Concern | Influence | Engagement Strategy |
|-------------|--------------------|-----------|---------------------|
| Chief Commercial Officer | Revenue recovery, retention | High | Executive sponsor, monthly steering |
| Head of Digital / E-commerce | Conversion, mobile UX | High | Weekly working sessions |
| Head of Customer Experience | NPS, support volume | High | Co-design of recovery & returns experience |
| Operations / Warehouse Lead | Refund SLA, process capacity | Medium-High | Process workshops, SLA definition |
| Marketing / CRM Lead | Campaign effectiveness, consent | Medium-High | Segment definitions & journey triggers |
| Finance | Revenue recognition, refund cost | Medium | Business case validation |
| IT / Product | Feasibility, integration effort | Medium | Technical feasibility & backlog input |
| Legal / Compliance | Consent, data usage | Medium | Early review of messaging rules |
| Front-line Support | Ticket volume, tools | Medium | Feedback on current pain points |

## RACI for Major Workstreams

| Activity | CCO | Digital | CX | Ops | Marketing | Finance | IT/Product | BA |
|----------|-----|---------|----|-----|-----------|---------|------------|-----|
| Problem framing & opportunity sizing | A | C | C | I | C | C | I | R |
| AS-IS / TO-BE process mapping | I | C | A | R | C | I | C | R |
| Statistical analysis & insights | A | C | C | I | C | C | I | R |
| Requirements prioritisation | A | R | C | C | C | C | C | R |
| Business case & roadmap | A | C | C | C | C | R | C | R |
| User stories & acceptance criteria | I | C | C | C | C | I | A | R |
| A/B test design (recovery) | I | A | C | I | R | I | C | C |
| Dashboard & KPI ownership | A | C | C | C | C | C | R | C |

**Legend:** R = Responsible, A = Accountable, C = Consulted, I = Informed

This matrix ensures clear ownership and prevents the common BA pitfall of “everyone is interested but no one owns the outcome”.
