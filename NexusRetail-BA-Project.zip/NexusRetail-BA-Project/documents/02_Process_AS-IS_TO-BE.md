# Process Analysis: AS-IS → TO-BE  

*Swimlane diagrams: `diagrams/01_checkout_cart_recovery_AS-IS_TO-BE.png` and `diagrams/02_returns_refund_AS-IS_TO-BE.png`.*

**Focus Areas:** Cart → Checkout → Order Confirmation & Returns → Refund

---

## 1. AS-IS: Cart Abandonment & Checkout Journey

**Actors:** Customer, Web/Mobile Front-end, Payment Gateway, OMS, CRM, Support

**High-level steps (current):**
1. Customer adds items to cart
2. Proceeds to checkout (or abandons)
3. Enters shipping / billing details
4. Selects payment method
5. Payment is attempted
6. On success → order confirmation + email
7. On failure → generic error, customer often leaves
8. Abandoned carts are only partially recovered via nightly batch email (per process review; the dataset contains no email or recovery data)

**Observed in data:** Mobile abandonment is 10.9 pp higher than Desktop; abandonment is 75.0% when payment fails (38.0% otherwise).

**Hypotheses from process review (to be validated – the dataset has no checkout-step data):**
- Mobile checkout requires more steps / form fields than desktop
- Payment failure messages are technical and non-actionable
- No real-time intervention while customer is still “warm”
- Recovery emails sent too late and not personalised by cart value or segment

**Key metric impact:** 40.3% abandonment overall; 45% on Mobile; 75% when payment fails.

---

## 2. AS-IS: Returns & Refund Process

**Current flow (simplified swimlane):**
- Customer initiates return (email / phone / form)
- Support creates ticket and requests photos / reason
- Warehouse receives item (variable transit time)
- Quality check performed
- Finance manually processes refund (batch)
- Customer receives funds (refund processing time: median 15 days, range 3–27 days in the data)
- Status visibility for customer is limited → expected increase in support contacts (hypothesis; not visible in the data)

**Pain points:**
- Average 15.1 days end-to-end (median 15, P90 25); only 19.7% of refunds complete within 7 days
- Multiple hand-offs and manual steps (process review – stage durations are not measured in the dataset)
- Customer has no self-service status tracking
- Return-related support contacts are not visible in the data (support-ticket rate is 4.3% on returned orders vs 12.2% on other completed orders), so ticket-volume reduction is not quantified

---

## 3. TO-BE Target State

### Checkout & Recovery
- Real-time abandonment detection (event-driven)
- Immediate, personalised recovery offer (push / email / SMS) based on cart value + segment
- One-tap guest checkout + digital wallets on mobile
- Contextual payment failure recovery (retry, alternative method, save cart)
- A/B testing framework for recovery messages and incentives

### Returns & Refunds
- Self-service returns portal with QR label generation
- Automatic status updates at each milestone (received → inspected → refunded)
- Target SLA: refund completed within 5 business days (same measure as `refund_processing_days`)
- Proactive communication intended to reduce inbound support contacts (hypothesis to be measured)
- Integration with loyalty / store credit options for faster resolution

---

## 4. Gap Summary & Required Changes

| Area | Gap | Required Capability |
|------|-----|---------------------|
| Detection | Batch only | Real-time event stream |
| Messaging | Generic, delayed | Personalised, multi-channel, rules-based |
| Mobile UX | High friction | Reduced form fields, guest path, wallets |
| Refund visibility | Opaque | Customer-facing status timeline |
| Cross-team ownership | Fragmented | Clear RACI + shared KPIs |

---

## 5. Process KPIs (TO-BE)

- Cart recovery rate (recovered / abandoned)
- Checkout completion rate by device
- Refund cycle time (P50 / P90)
- % of returns resolved without human ticket
- NPS / CSAT of return experience

These process changes are directly linked to the functional requirements in the BRD summary and the prioritised recommendations document.
