#!/usr/bin/env python3
"""
NexusRetail BA Project - data validation.

Runs integrity checks on the CSV files in ../data and exits with code 1 if any fails.
    python analysis/validate_data.py [data_dir]
"""
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
DATA = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "data"

full = pd.read_csv(DATA / "full_dataset.csv", parse_dates=["order_date"])
orders = pd.read_csv(DATA / "orders.csv", parse_dates=["order_date"])
cust = pd.read_csv(DATA / "customers.csv")

done = full.cart_abandoned == 0
checks = [
    ("42,000 sessions and 8,500 customers", len(full) == 42000 and len(cust) == 8500),
    ("order_id unique", full.order_id.is_unique),
    ("customer_id unique in customers.csv", cust.customer_id.is_unique),
    ("every session maps to a customer", bool(full.customer_id.isin(cust.customer_id).all())),
    ("no missing values except refund_processing_days",
     int(full.drop(columns="refund_processing_days").isna().sum().sum()) == 0 and int(cust.isna().sum().sum()) == 0),
    ("period is 2025-01-01 .. 2025-12-31",
     full.order_date.min() == pd.Timestamp("2025-01-01") and full.order_date.max() == pd.Timestamp("2025-12-31")),
    ("flags are 0/1", all(full[c].isin([0, 1]).all() for c in
                          ["cart_abandoned", "returned", "payment_failed", "had_support_ticket"])),
    ("returns only on completed orders", bool(((full.returned == 1) <= done).all())),
    ("refund_processing_days present exactly when returned = 1",
     bool((full.returned == 1).eq(full.refund_processing_days.notna()).all())),
    ("order_value > 0", bool((full.order_value > 0).all())),
    ("session-level customer attributes match customers.csv",
     bool(full.merge(cust, on="customer_id", suffixes=("", "_c"))
          .pipe(lambda m: all((m[c] == m[c + "_c"]).all() for c in
                              ["segment", "country", "acquisition_channel", "last_purchase_days_ago"])))),
    ("orders.csv equals the order-level columns of full_dataset.csv",
     bool(orders.fillna(-1).equals(full[orders.columns].fillna(-1)))),
    ("At-Risk customers: last purchase 45-118 days ago",
     bool(cust[cust.segment == "At-Risk"].last_purchase_days_ago.between(45, 118).all())),
    ("Churned customers: last purchase 120+ days ago",
     bool((cust[cust.segment == "Churned"].last_purchase_days_ago >= 120).all())),
    ("New / Occasional / Loyal customers: last purchase within 43 days",
     bool((cust[cust.segment.isin(["New", "Occasional", "Loyal"])].last_purchase_days_ago <= 43).all())),
]

failed = 0
for name, ok in checks:
    print(("PASS  " if ok else "FAIL  ") + name)
    failed += (not ok)
print(f"\n{len(checks) - failed}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
