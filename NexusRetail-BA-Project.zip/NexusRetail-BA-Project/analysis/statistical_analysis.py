#!/usr/bin/env python3
"""
NexusRetail BA Project - Reproducible statistical analysis.

Usage (from the project root):
    python analysis/statistical_analysis.py [data_dir] [output_dir]
Reads data/*.csv, checks integrity and writes outputs/key_statistics.json.
Every number quoted in the README, documents and Excel workbook comes from this
script (or the equivalent Excel formulas).
"""
import json
import sys
from pathlib import Path

import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
DATA = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "data"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE.parent / "outputs"
OUT.mkdir(exist_ok=True, parents=True)

RECOVERY_RATE = 0.18   # base-case assumption (not derived from data)


def pct(x, n=2):
    return round(float(x) * 100, n)


def main():
    df = pd.read_csv(DATA / "full_dataset.csv", parse_dates=["order_date"])
    cust = pd.read_csv(DATA / "customers.csv")

    # ---- integrity guards: fail loudly instead of reporting wrong numbers
    assert df.order_id.is_unique
    assert ((df.returned == 1) <= (df.cart_abandoned == 0)).all(), "return on abandoned cart"
    assert (df.returned == 1).eq(df.refund_processing_days.notna()).all(), "refund days / returned mismatch"

    done = df[df.cart_abandoned == 0]
    aband = df[df.cart_abandoned == 1]
    ret = df[df.returned == 1]
    R = {}

    # ---- Funnel
    R["funnel"] = {
        "total_sessions": len(df),
        "completed_orders": len(done),
        "abandoned_carts": len(aband),
        "conversion_rate_pct": pct(len(done) / len(df)),
        "abandonment_rate_pct": pct(len(aband) / len(df)),
        "period": f"{df.order_date.min().date()} to {df.order_date.max().date()}",
    }

    # ---- Revenue (period = 12 months, so values are annual)
    ab_val = aband.order_value.sum()
    R["revenue"] = {
        "completed_revenue_eur": round(done.order_value.sum()),
        "abandoned_cart_value_eur": round(ab_val),
        "recovery_rate_assumption_pct": pct(RECOVERY_RATE, 0),
        "estimated_recoverable_eur": round(ab_val * RECOVERY_RATE),
        "avg_order_value_completed_eur": round(done.order_value.mean(), 2),
        "avg_abandoned_cart_value_eur": round(aband.order_value.mean(), 2),
    }

    # ---- Device
    g = df.groupby("device").agg(sessions=("order_id", "size"), abandoned=("cart_abandoned", "sum"))
    g["rate"] = g.abandoned / g.sessions
    g["share_of_sessions"] = g.sessions / len(df)
    g["abandoned_value"] = aband.groupby("device").order_value.sum()
    R["device"] = {d: {"sessions": int(r.sessions), "share_of_sessions_pct": pct(r.share_of_sessions),
                       "abandonment_pct": pct(r.rate), "abandoned_value_eur": round(r.abandoned_value)}
                   for d, r in g.iterrows()}
    mob, desk = g.loc["Mobile"], g.loc["Desktop"]
    excess_n = (mob.rate - desk.rate) * mob.sessions
    R["mobile_gap"] = {
        "gap_pp": round((mob.rate - desk.rate) * 100, 1),
        "excess_abandoned_carts_vs_desktop": round(excess_n),
        "excess_value_eur": round(excess_n * aband[aband.device == "Mobile"].order_value.mean()),
    }
    ct = pd.crosstab(df.device == "Mobile", df.cart_abandoned)
    chi2, p, _, _ = stats.chi2_contingency(ct)
    sub = df[df.device.isin(["Mobile", "Desktop"])]
    chi2_d, p_d, _, _ = stats.chi2_contingency(pd.crosstab(sub.device, sub.cart_abandoned))
    R["stats_tests"] = {
        "mobile_vs_rest_chi2": round(chi2, 1), "mobile_vs_rest_p_value": float(f"{p:.3e}"),
        "mobile_vs_desktop_chi2": round(chi2_d, 1), "mobile_vs_desktop_p_value": float(f"{p_d:.3e}"),
        "significant_at_5pct": bool(p < 0.05 and p_d < 0.05),
    }

    # ---- Payment failure
    pg = df.groupby("payment_failed").agg(n=("order_id", "size"), rate=("cart_abandoned", "mean"),
                                           ab=("cart_abandoned", "sum"))
    fail, ok = pg.loc[1], pg.loc[0]
    ct = pd.crosstab(df.payment_failed, df.cart_abandoned)
    chi2p, pp, _, _ = stats.chi2_contingency(ct)
    R["payment_failure"] = {
        "share_of_sessions_pct": pct(fail.n / len(df)),
        "abandon_when_ok_pct": pct(ok.rate),
        "abandon_when_fail_pct": pct(fail.rate),
        "share_of_all_abandoned_carts_pct": pct(fail.ab / len(aband)),
        "abandoned_value_with_payment_failure_eur": round(aband[aband.payment_failed == 1].order_value.sum()),
        "excess_abandoned_carts_vs_ok": round((fail.rate - ok.rate) * fail.n),
        "chi2_p_value": float(f"{pp:.3e}"),
    }

    # ---- Channel & segment (abandonment does NOT differ materially)
    R["channel_abandon_pct"] = {k: pct(v) for k, v in df.groupby("sales_channel").cart_abandoned.mean().items()}
    R["segment_abandon_pct"] = {k: pct(v) for k, v in df.groupby("segment").cart_abandoned.mean().items()}

    # ---- Returns (valid returns only: completed orders with refund days)
    tick = done.groupby("returned").had_support_ticket.mean()
    R["returns"] = {
        "valid_returns": len(ret),
        "return_rate_pct_of_completed": pct(len(ret) / len(done)),
        "avg_refund_days": round(ret.refund_processing_days.astype(float).mean(), 1),
        "median_refund_days": round(float(ret.refund_processing_days.astype(float).median()), 1),
        "p90_refund_days": round(float(ret.refund_processing_days.astype(float).quantile(0.9)), 1),
        "pct_refunds_within_7_days": pct((ret.refund_processing_days <= 7).mean()),
        "pct_refunds_within_5_days": pct((ret.refund_processing_days <= 5).mean()),
        "support_ticket_rate_returned_pct": pct(tick.get(1, 0)),
        "support_ticket_rate_not_returned_pct": pct(tick.get(0, 0)),
    }

    # ---- Customer health (customer table, 8,500 customers)
    seg = cust.segment.value_counts()
    sp = cust.segment.value_counts(normalize=True)
    R["customer_health"] = {k.lower().replace("-", "_") + "_pct": pct(sp.get(k, 0), 1)
                            for k in ["Loyal", "At-Risk", "Churned", "New", "Occasional"]}
    R["customer_health"].update({"customers": len(cust), "at_risk_customers": int(seg["At-Risk"]),
                                 "churned_customers": int(seg["Churned"])})
    rec = cust.groupby("segment").last_purchase_days_ago.agg(["min", "max"])
    R["segment_recency_days"] = {k: {"min": int(r["min"]), "max": int(r["max"])} for k, r in rec.iterrows()}
    R["segment_avg_lifetime_orders"] = {k: round(float(v), 1) for k, v in
                                        cust.groupby("segment").total_orders_lifetime.mean().items()}

    # ---- Quarterly stability
    q = df.groupby(df.order_date.dt.to_period("Q")).cart_abandoned.mean()
    R["quarterly_abandon_pct"] = {str(k): pct(v) for k, v in q.items()}

    with open(OUT / "key_statistics.json", "w", encoding="utf-8") as f:
        json.dump(R, f, indent=2, ensure_ascii=False)
    print(json.dumps(R, indent=2, ensure_ascii=False))
    print(f"\nSaved to {OUT / 'key_statistics.json'}")


if __name__ == "__main__":
    main()
