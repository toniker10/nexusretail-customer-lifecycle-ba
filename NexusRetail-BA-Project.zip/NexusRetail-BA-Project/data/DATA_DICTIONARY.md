# Data dictionary

All data is synthetic. Column descriptions are based on column names and observed values, because the source system is fictional. One row in `full_dataset.csv` / `orders.csv` is one cart session (`order_id`); the session either ended in a completed order or was abandoned.

## full_dataset.csv (42,000 rows) and orders.csv
`orders.csv` holds the first 12 columns only.

| Column | Description |
|---|---|
| order_id | Unique session / order identifier |
| customer_id | Customer identifier (links to customers.csv) |
| order_date | Date of the session (2025-01-01 to 2025-12-31) |
| order_value | Cart or order value in EUR (8–480) |
| cart_abandoned | 1 = cart abandoned, 0 = order completed |
| returned | 1 = valid return (completed order with refund days), else 0 |
| refund_processing_days | Calendar days to complete the refund; filled only when returned = 1 (start point not documented) |
| sales_channel | Web, Mobile App or Marketplace (does not always agree with `device`) |
| device | Desktop, Mobile or Tablet |
| payment_failed | 1 = at least one payment failure in the session |
| had_support_ticket | 1 = the session had a support ticket |
| items_in_cart | Number of items (1–12) |

The remaining columns (`segment` … `last_purchase_days_ago`) are the customer attributes below, repeated on each session.

## customers.csv (8,500 rows)
| Column | Description |
|---|---|
| customer_id | Unique customer identifier |
| segment | New, Occasional, Loyal, At-Risk or Churned. At-Risk = last purchase 45–118 days ago; Churned = 120+ days; New / Occasional / Loyal = within 43 days (definitions not documented) |
| acquisition_channel | Organic, Paid Social, Referral, Email or Marketplace |
| country | GR, CY, DE, IT, FR or ES |
| tenure_days | Days since the customer registered |
| avg_historical_aov | Average historical order value (EUR) |
| total_orders_lifetime | Lifetime number of orders |
| is_subscribed_newsletter | 1 = subscribed |
| last_purchase_days_ago | Days since the last purchase |

## data_quality_log.csv
Data preparation notes and known limitations (see also the `Data_Quality` sheet of the Excel workbook).
