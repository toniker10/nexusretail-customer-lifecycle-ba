# Diagrams

| File | Content |
|---|---|
| `01_checkout_cart_recovery_AS-IS_TO-BE.png` / `.svg` | Checkout and cart recovery swimlane: AS-IS vs TO-BE |
| `02_returns_refund_AS-IS_TO-BE.png` / `.svg` | Returns and refund swimlane: AS-IS vs TO-BE |

Red boxes mark pain points, green boxes mark proposed improvements. Items marked * are process-review hypotheses that the dataset does not measure. Figures come from `outputs/key_statistics.json` and the Excel workbook.
